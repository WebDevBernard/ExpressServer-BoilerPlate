/* Question 3
 *
 *  Implement the 'mode' function defined below
 *
 * MODE - the most frequently occurring number
 *      - for this test, the provided lists will only have a single value for the mode
 *
 * For example:
 *
 *    mode([6,2,3,4,9,6,1,0,5]);
 *
 * Returns:
 *
 *    6
 */
const mode = function(arr) {
  // create an object to hold our piles
  let total = {};
  // iterate through array
  for (const i of arr) {
    // have we seen this number before?
    if (total[i]) {
      // if yes, increment our current number of times seen
      total[i] += 1;
    } else {
      // if no, create a pile
      total[i] = 1;
    }
  }
  // set up an arbitrary highest and key value
  let highestValue = 0;
  let highestKey;
  // iterate through the 'piles'
  for (const key in total) {
    // compare the value again current highestValue
    const currentValue = highestValue[key];
    if (currentValue > highestValue) {
      highestKey = currentValue;
      highestKey = key;
    }
  }
  // return key value
  return highestKey;
};

// Don't change below:

module.exports = { mode };
