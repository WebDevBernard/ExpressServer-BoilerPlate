/* Question 2
 *
 *  Implement the functions defined below
 *
 */

// Meant to be used by medium. Do not alter.
const round = function(number) {
  return Math.round(number * 100) / 100;
};

/* ===========================================================================
 * MEDIAN - the middle number of a list (when sorted)
 *        - if the list length is even, then the median is the average of the two middle values
 *        - use the provided 'round' function before returning your value
 *
 * For example:
 *
 *    median([6,2,3,4,9,6,1,0,5]);
 *
 * Returns:
 *
 *    4
 */
const median = function(arr) {
  let total = arr.length / 2;
  arr.sort();
  if (arr.length % 2 === 0) {
    return round((arr[total] + arr[total - 1]) / 2);
  }
  return round((arr[Math.floor(total)]));
};

// Don't change below:

module.exports = { median };
