-- =========== --
-- QUESTION 03 --
-- =========== --
--
-- Fetch the number of books which cost more than $7

-- ============ --
-- TEST COMMAND --
-- ============ --
--
-- sqlite3 -column -header supporting-files/test.sqlite3 < answers/03.sql

-- ================ --
-- EXPECTED RESULTS --
-- ================ --
--------
-- count    <== NOTE: any column name is fine
-- -----
-- 8
--------

-- ============ --
-- SQL SOLUTION --
-- ============ --
--
-- MODIFY THE QUERY BELOW:

SELECT count(title)
FROM books
WHERE price_cents > 700;
