<<-CHALLENGE00

At the bottom of this file, create a Calculator class.

Calculator#sum should have one instance method called sum.

It should take in two arguments and return their sum, plain and simple.

CHALLENGE00

class Calculator
  def sum(a, b)
    a + b
  end
end